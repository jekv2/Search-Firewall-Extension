const input = document.getElementById("input");
const add = document.getElementById("add");
const list = document.getElementById("list");

function render() {
  chrome.storage.sync.get(["excludedDomains"], (data) => {
    const items = data.excludedDomains || [];
    list.innerHTML = "";

    items.forEach((d, i) => {
      const div = document.createElement("div");
      div.style.display = "flex";
      div.style.justifyContent = "space-between";

      div.innerHTML = `
        <span>${d}</span>
        <span style="cursor:pointer;color:red;">✕</span>
      `;

      div.querySelector("span:last-child").onclick = () => {
        items.splice(i, 1);
        chrome.storage.sync.set({ excludedDomains: items }, render);
      };

      list.appendChild(div);
    });
  });
}

add.onclick = () => {
  const val = input.value.trim().toLowerCase();
  if (!val) return;

  chrome.storage.sync.get(["excludedDomains"], (data) => {
    const list = data.excludedDomains || [];

    if (!list.includes(val)) list.push(val);

    chrome.storage.sync.set({ excludedDomains: list }, () => {
      input.value = "";
      render();
    });
  });
};

render();