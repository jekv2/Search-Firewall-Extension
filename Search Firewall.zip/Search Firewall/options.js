const box = document.getElementById("domains");
const save = document.getElementById("save");
const checkboxes = document.querySelectorAll("input[type=checkbox]");

const engineMap = {
  google: "google",
  startpage: "startpage",
  duckduckgo: "duckduckgo",
  bing: "bing",
  brave: "brave",
  yahoo: "yahoo"
};

// LOAD
chrome.storage.sync.get(["excludedDomains", "enabledEngines"], (data) => {
  const domains = data.excludedDomains || [];
  const engines = data.enabledEngines || [];

  // domains
  box.value = domains.join("\n");

  // engines
  checkboxes.forEach(cb => {
    if (engineMap[cb.value]) {
      cb.checked = engines.includes(cb.value);
    }
  });
});

// SAVE
save.onclick = () => {
  const domains = box.value
    .split("\n")
    .map(x => x.trim().toLowerCase())
    .filter(Boolean);

  const engines = Array.from(checkboxes)
    .filter(cb => cb.checked)
    .map(cb => cb.value);

  chrome.storage.sync.set({
    excludedDomains: domains,
    enabledEngines: engines
  }, () => {
    alert("Saved ✔");
  });
};