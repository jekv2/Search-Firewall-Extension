function normalize(domain) {
  return domain
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .split("/")[0];
}

function getEngine() {
  const host = location.hostname;

  if (host.includes("google.")) return "google";
  if (host.includes("startpage.")) return "startpage";
  if (host.includes("duckduckgo.")) return "duckduckgo";
  if (host.includes("bing.")) return "bing";
  if (host.includes("brave.")) return "brave";
  if (host.includes("yahoo.")) return "yahoo";

  return null;
}

// hide blocked results
function filterResults(domains) {
  document.querySelectorAll("a").forEach(a => {
    const href = (a.href || "").toLowerCase();

    for (const d of domains) {
      if (href.includes(d)) {
        const box = a.closest("div");
        if (box) box.style.display = "none";
      }
    }
  });
}

// ADD "BLOCK DOMAIN" BUTTON
function injectBlockButtons() {
  document.querySelectorAll("a").forEach(a => {
    if (a.dataset.blockAdded) return;

    const href = a.href;
    if (!href) return;

    const btn = document.createElement("button");
    btn.innerText = "Block domain";
    btn.style.marginLeft = "8px";
    btn.style.fontSize = "11px";
    btn.style.cursor = "pointer";

    btn.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();

      const domain = new URL(href).hostname;

      chrome.storage.sync.get(["excludedDomains"], (data) => {
        const list = data.excludedDomains || [];
        const clean = normalize(domain);

        if (!list.includes(clean)) {
          list.push(clean);
          chrome.storage.sync.set({ excludedDomains: list });
        }
      });

      const box = a.closest("div");
      if (box) box.style.display = "none";
    };

    a.parentElement?.appendChild(btn);
    a.dataset.blockAdded = "1";
  });
}

// MAIN RUN
function run() {
  const engine = getEngine();

  chrome.storage.sync.get(["excludedDomains", "enabledEngines"], (data) => {
    const enabled = data.enabledEngines || [];
    const domains = (data.excludedDomains || []).map(normalize);

    if (!engine || !enabled.includes(engine)) return;

    filterResults(domains);
    injectBlockButtons();
  });
}

// keep alive for dynamic pages like Startpage
const observer = new MutationObserver(run);
observer.observe(document.body, { childList: true, subtree: true });

run();