let lastBlocked = null;

// Right-click menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "block-domain",
    title: "Block this domain",
    contexts: ["link"]
  });

  chrome.contextMenus.create({
    id: "undo-block",
    title: "Undo last block",
    contexts: ["action"]
  });
});

// Right-click handler
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "block-domain") {
    const url = new URL(info.linkUrl);
    const domain = url.hostname;

    chrome.storage.sync.get(["excludedDomains"], (data) => {
      const list = data.excludedDomains || [];
      if (!list.includes(domain)) {
        list.push(domain);
        chrome.storage.sync.set({ excludedDomains: list });
      }
      lastBlocked = domain;
    });
  }

  if (info.menuItemId === "undo-block") {
    chrome.storage.sync.get(["excludedDomains"], (data) => {
      let list = data.excludedDomains || [];
      if (lastBlocked) {
        list = list.filter(d => d !== lastBlocked);
        chrome.storage.sync.set({ excludedDomains: list });
      }
    });
  }
});